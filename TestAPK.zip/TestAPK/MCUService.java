package com.android.server;
import com.android.server.am.ActivityManagerService;
import com.android.server.power.PowerManagerService;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.ServiceManager;
import android.os.PowerManager;
import android.os.SystemClock;
import android.app.IMCUManager;
import java.lang.reflect.Method;
import android.os.Handler;
import java.lang.Process;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.SystemProperties;
import android.content.ContentResolver;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;

import java.text.SimpleDateFormat;
import java.util.Date;
import android.widget.EditText;
import android.view.KeyEvent;
import android.view.IWindowManager;
import android.hardware.input.InputManager;
import java.io.RandomAccessFile;
import android.util.Log;
import android.net.Uri;
import android.os.RemoteException;
import android.content.pm.IPackageInstallObserver;
import android.content.pm.IPackageManager;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.view.KeyEvent;
import android.app.Instrumentation;
import android.hardware.input.InputManager;
import android.os.SystemClock;
import android.app.ActivityManager.RunningTaskInfo;
import java.util.ArrayList;
import android.app.ActivityManager;
import java.util.List;
import android.content.ComponentName;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class MCUService extends IMCUManager.Stub {

	private static final String TAG = "mcu_SerialPort";

	private Context mContext;
	/*
	 * Do not remove or rename the field mFd: it is used by native method close();
	 */
	private FileDescriptor mFd;
	private FileInputStream mFileInputStream;
	private FileOutputStream mFileOutputStream;
	private SimpleDateFormat format=new SimpleDateFormat("yy-MM-dd HH:mm:ss");  
	private Handler mPowerofHandler = new Handler();
	private long m_delayTime;
	private long m_oneDayTime = 24*60*60*1000;
	private boolean poweroff_flag;
	private boolean powerOff_every;
	private String[] PowerTimeFlag;
	PowerManager mPowerManager;
	private boolean mcuwatchdogFlag;
	private ReadThread mReadThread;
	private String[] mcuVersionbuf=new String[10];
	private int m_pos=0;
	private String mcuVersion;
	
	private static File blue_led = new File("/sys/class/backlight/rk28_bl/blue");
												
	private static File red_led = new File("/sys/class/backlight/rk28_bl/red");
	public final static String OPEN_POWER = "0001";
	public final static String CLOSE_POWER = "0000";
	
	private  boolean openBlueLed() {
		Log.i("222222", "openBlueLed");
		return writeStringToFile(blue_led, OPEN_POWER);
	}
	private  boolean closeBlueLed() {
		Log.i("222222", "closeBlueLed");
		return writeStringToFile(blue_led, CLOSE_POWER);
	}
	private  boolean openRedLed() {
		Log.i("222222", "openRedLed");
		return writeStringToFile(red_led, OPEN_POWER);
	}
	private  boolean closeRedLed() {
		Log.i("222222", "closeRedLed");
		return writeStringToFile(red_led, CLOSE_POWER);
	}
	private  boolean writeStringToFile(File file, String str) {
		if (!file.exists()) {
			Log.d("222222", "File not exist");
			return false;
		}
		try {
			RandomAccessFile raf = new RandomAccessFile(file, "rw");
			char[] toChar = str.toCharArray();
			byte[] buffer = new byte[toChar.length];
			for (int i = 0; i < buffer.length; i++) {
				buffer[i] = (byte) toChar[i];
			}
			raf.write(buffer);
			return true;
		} catch (IOException e) {
			Log.w(TAG, "Exception opening file: " + file.getAbsolutePath(), e);
		}
		return false;
	}
	private long GetPowerOffTime(String m_hour,String m_min)
	{   
	      if((0<=Integer.parseInt(m_hour))&&(Integer.parseInt(m_hour)<=24)&&(0<=Integer.parseInt(m_min))&&(Integer.parseInt(m_min)<=60))
	      {
				      m_delayTime= (60* Integer.parseInt(m_hour)+Integer.parseInt(m_min))*60000;
				      long currenttime=System.currentTimeMillis();
				      Date currendate=new Date(currenttime);  
		          String time=format.format(currendate); 
							String strcurtmp[];
						  strcurtmp=time.split(" ");
							strcurtmp=strcurtmp[1].split(":");
							m_delayTime=m_delayTime-(60* Integer.parseInt(strcurtmp[0])+Integer.parseInt(strcurtmp[1]))*60000;
							Log.i(TAG,"get power off time delay is "+m_delayTime);
							if(m_delayTime<=0)
							{
									Log.e(TAG, " MCU_POWER_OFF_TIME is Invalid  off time < curtent time ");
									m_delayTime=m_delayTime + m_oneDayTime;
							}
							return m_delayTime;
	      }
	      else
	      {
		      	  Log.e(TAG, " MCU_POWER_OFF_TIME is Invalid m_hour="+m_hour+" m_min="+m_min);
			  			return m_delayTime=0xffffffff;
	      	
	      }
	}

	private void WritePowerOffTimeToConfig(Context mContext,String hour,String minute,boolean isOpened)
	{
			SharedPreferences sp = mContext.getSharedPreferences("poweroff_config", Context.MODE_PRIVATE);
			
			Editor editor = sp.edit();
			editor.putString("hour", hour);
			editor.putString("minute", minute);
			editor.putBoolean("isOpened", isOpened);		
			editor.commit();
	}
	private String[] readPowerOffTimeFromConfig(Context mContext)
	{
			SharedPreferences sp = mContext.getSharedPreferences("poweroff_config", Context.MODE_PRIVATE);
			String[] time = new String[3];
			if(sp.getBoolean("isOpened", false))
			{
				time[0] ="ON";
				time[1] = sp.getString("hour", "-1");
				time[2] = sp.getString("minute", "-1");
				Log.i(TAG,"read power off inf hour ="+time[1]+"min"+time[2]);
			}
			else
			{    // time[0] =0;
				Log.e("OKOK", "poweroff is closed");
				return null;
			}
			
			if(time[0] == "-1" || time[1] == "-1")
			{
				Log.e("OKOK", "poweroff time is not preseted");
				return null;
			}
			Log.d(TAG,"power off inf "+time[0]);
			return time;
	}
	public void SetMcuTime()
	{
		   long time=System.currentTimeMillis();
		   Date d1=new Date(time);  
       String t1=format.format(d1); 
		   t1= t1.replace(":","");
		   t1= t1.replace("-","");
		   t1= t1.replace(" ","");		  
		  //14-06-25 18:35:42		
		   String mcusystem="3"+t1;
       Log.d(TAG, mcusystem);
		   try
		   {		       
		       mFileOutputStream.write(mcusystem.getBytes());
		       mFileOutputStream.flush();
		   }
		 	 catch (Exception e)
			 {
		 	   e.printStackTrace();
		 	 }	
	      	
	}
	public void shutdown()
	{
			 Log.d(TAG, "enter shutdown");      
			 try 
			 {      
	          Class<?> ServiceManager = Class .forName("android.os.ServiceManager");
	          
	          Method getService = ServiceManager.getMethod("getService", java.lang.String.class);

	          Object oRemoteService = getService.invoke(null,Context.POWER_SERVICE);
	          
	          Class<?> cStub = Class
	             .forName("android.os.IPowerManager$Stub");
	          Method asInterface = cStub.getMethod("asInterface", android.os.IBinder.class);
	          Object oIPowerManager = asInterface.invoke(null, oRemoteService);
	          Method shutdown = oIPowerManager.getClass().getMethod("shutdown",boolean.class,boolean.class);
	          shutdown.invoke(oIPowerManager,false,true);           
		        
		   } catch (Exception e){         
		       
		   }
	}
	
	private Runnable DelayRunable = new Runnable() 
	{		
      @Override
      public void run() 
      {
					SetMcuTime();   
					try 
					{
				       Thread.sleep(200);
				       Log.d(TAG,"write mcu and power off");
				       mFileOutputStream.write("6".getBytes());
				       mFileOutputStream.flush();
							 // mFileOutputStream.close();
					 		 Thread.sleep(500);
					}
					catch(Exception e)	
					{
				 	 	e.printStackTrace();
					}						
					shutdown();		
			}
	};	

	public void MCUServiceInit()
	{
		   Log.i(TAG, "enter MCUServiceInit fuction");
		   return ;
	}
	public void  McuSerialPort(File device, int baudrate, int flags)  
	{
				Log.d(TAG, "enter McuSerialPort");
				/* Check access permission */
				if (!device.canRead() || !device.canWrite()) 
				{
						try {
							Process su;
							su = Runtime.getRuntime().exec("/system/xbin/su");
							String cmd = "chmod 666 " + device.getAbsolutePath() + "\n"
									+ "exit\n";
							Log.e(TAG, "McuSerialPort 11");
							su.getOutputStream().write(cmd.getBytes());
							Log.e(TAG, "McuSerialPort 22");
							if ((su.waitFor() != 0) || !device.canRead()
									|| !device.canWrite()) {
								throw new SecurityException();
							}
						} catch (Exception e) {
							e.printStackTrace();
							throw new SecurityException();
						}
				}
				Log.e(TAG, "McuSerialPort 33");
				mFd = SerialPort_open(device.getAbsolutePath(), baudrate, flags);
				if (mFd == null) {
					Log.e(TAG, "native open returns null");
				}
				Log.e(TAG, "McuSerialPort 44");
				mFileInputStream = new FileInputStream(mFd);
				mFileOutputStream = new FileOutputStream(mFd);
				/*mReadThread = new ReadThread();
				mReadThread.start();*/
	}

	MCUService(Context context)
	{
		   Log.d(TAG, "enter MCUService");
			 poweroff_flag=false;
			 powerOff_every=false;
			 mcuwatchdogFlag=false;
		   McuSerialPort(new File("/dev/ttyS3"), 9600, 0);		        
		   mContext = context;   
			 mPowerManager = (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
			 IntentFilter filter = new IntentFilter();      
			 filter.addAction(Intent.MCU_SHUT_DOWN); 
			 filter.addAction(Intent.MCU_POWER_ON_TIME); 
			 filter.addAction(Intent.MCU_POWER_OFF_TIME); 
			 filter.addAction(Intent.MCU_WATCHDOG_ENABLE); 
			 filter.addAction(Intent.MCU_WATCHDOG_DISABLE);
			 filter.addAction(Intent.ACTION_TIME_CHANGED);
			 filter.addAction(Intent.MCU_REBOOT);
			 filter.addAction(Intent.MCU_SLEEP);
			 filter.addAction(Intent.ACTION_SCREEN_ON);
			 filter.addAction(Intent.ACTION_SCREEN_OFF);
			 filter.addAction(Intent.ACTION_BOOT_COMPLETED);
			 filter.addAction("xy.update.third.apk.start");
			 filter.addAction(Intent.MCU_POWER_ON_EVERY_TIME);
			 filter.addAction(Intent.MCU_POWER_OFF_EVERY_TIME);
			 context.registerReceiver(mIntentReceiver, filter);
			 
			 PowerTimeFlag=readPowerOffTimeFromConfig(this.mContext);
			 if(PowerTimeFlag!=null&&PowerTimeFlag[0]=="ON")
			 {
			    	m_delayTime=GetPowerOffTime(PowerTimeFlag[1],PowerTimeFlag[2]);
			   		mPowerofHandler.postDelayed(DelayRunable,m_delayTime);	
		        poweroff_flag=true; 
		        powerOff_every=true;
			 }
	}
	public void SerialPortWrite(String strcmd)
	{
		   try
		   {		       
		       mFileOutputStream.write(strcmd.getBytes());
		       mFileOutputStream.flush();
		   }
		   catch (Exception e)
			 {
		 	   e.printStackTrace();
		   }
	}
	private String byte2HexStr(byte[] b,int size)    
	{    
    String stmp="";    
    StringBuilder sb = new StringBuilder("");    
    for (int n=0;n<size;n++)    
    {    
        stmp = Integer.toHexString(b[n] & 0xFF);    
        sb.append((stmp.length()==1)? "0"+stmp : stmp);    
        sb.append(" ");    
    }    
    return sb.toString().toUpperCase().trim();    
	}    
	protected void onDataReceived(final byte[] buffer, final int size) 
	{
		int i;
		
		Log.d("mcu","size:"+size);
		String str=byte2HexStr(buffer,size);
		mcuVersionbuf[m_pos++]=str;
		if(m_pos==4)
		{
			mcuVersion=mcuVersionbuf[0]+mcuVersionbuf[1]+mcuVersionbuf[2]+mcuVersionbuf[3];
			m_pos=0;
			Log.d("mcu","mcuVersion:" + mcuVersion);
		}

	}
	private class ReadThread extends Thread {

		@Override
		public void run() {
			super.run();
			while(!isInterrupted()) {
				int size;
				int available = 0; 
				try {
					byte[] buffer = new byte[0xFF];
					if (mFileInputStream == null) 
								return;
					available=mFileInputStream.available();
					if(available>0)
					{ 			
							size = mFileInputStream.read(buffer);
							if (size > 0) 
							{
								onDataReceived(buffer, size);
							}
					}
				} catch (IOException e) {
					e.printStackTrace();
					return;
				}
			}
		}
	}
	BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
	{
        public void onReceive(Context context, Intent intent) 
        {
            if (intent.getAction().equals(Intent.MCU_SHUT_DOWN)) 
            {
                Log.d(TAG, "receiver intent MCU_SHUT_DOWN ");
								SetMcuTime();
							  try 
							  {
							  	   Thread.sleep(200);
								     mFileOutputStream.write("6".getBytes());
								     mFileOutputStream.flush();
									   Thread.sleep(100);
								}
								catch(Exception e)	
								{
							 	 e.printStackTrace();
								}
							  shutdown();	       
            }
            if (intent.getAction().equals(Intent.MCU_POWER_ON_EVERY_TIME)){
            	String strEveryTime=intent.getStringExtra("etPowerOn");
							Log.e("eric", "MCU_POWER_ON_EVERY_TIME  str= "+strEveryTime);
            	if(strEveryTime.equals("0,0,0,0,0,0,0,0")==true)
							  {
							   			try
							   			{
							   					System.out.println("cancelpoweron");
							      			String cancelPowerOnStr = "2";
							       			mFileOutputStream.write(cancelPowerOnStr.getBytes());
							       			mFileOutputStream.flush();
							    		}
							    		catch (Exception e)
							    		{
							 	   			e.printStackTrace();
							 	   		}
							  }else{
							  			String[] strtmp=strEveryTime.split(",");	
							  			try
											{
							  	         	String str_hour;
				                		String str_min;
				                		if(strtmp[3].length()==1){
		 		                			 str_hour="0"+strtmp[3];
		 		                		}else{
		 		                			 str_hour=strtmp[3];
		 		                		}
				                		if(strtmp[4].length()==1){
		 		                			 str_min="0"+strtmp[4];
		 		                		}else{
		 		                			 str_min=strtmp[4];
		 		                		}				                	
				                
		                     		String mcusend = "1" + str_hour+ str_min+ "00";
				                		Log.d(TAG, "set MCU_POWER_ON_TIME  str= "+mcusend);
		                    		mFileOutputStream.write(mcusend.getBytes());
		                    		mFileOutputStream.flush();	
		                    		
		                    			String str= "Power_on_time:" +"1,0,0,"+ str_hour +"," + str_min + ",0,0,0";
										    			try
										    			{
										    					Log.d("time is",str);
																	writeSDFile("/mnt/sdcard/etPowerOn.txt",str);
															}
															catch (IOException e) 
															{
																	e.printStackTrace();
										    			}		                    			                	
		 		                	}
		 		                	catch (Exception e)
				                	{
		 		                		e.printStackTrace();
		 		                	}
		 		                	SetMcuTime(); 					        					        		  	
							  	}
            }
            if (intent.getAction().equals(Intent.MCU_POWER_OFF_EVERY_TIME)) {
            	String strpoweroff=intent.getStringExtra("etPower");
            	Log.e("eric","MCU_POWER_OFF_EVERY_TIME:    "+strpoweroff);
            	          	        
            	if(powerOff_every)
		    	   	{
		    		 	 Log.d(TAG, "  again set power off  delay ="+m_delayTime);
		   			  	mPowerofHandler.removeCallbacks(DelayRunable);		      
		   		   	}
		   		  	if(strpoweroff.equals("cancel")==true)
				    	{
					   	 Log.d(TAG, "power  power cancel ");
					    	powerOff_every=false; 
				   		 } else{
				   		 		String[] strtmp=strpoweroff.split(",");
					   	 		m_delayTime=GetPowerOffTime(strtmp[3],strtmp[4]);
				      		Log.e(TAG, "  MCU_POWER_OFF delay ="+m_delayTime);
		        			mPowerofHandler.postDelayed(DelayRunable,m_delayTime);	
		        			powerOff_every=true; 
					    		WritePowerOffTimeToConfig(mContext,strtmp[3],strtmp[4],true);
					    		
					    		String str= "Power_off_time:" +"1,0,0,"+ strtmp[3] +"," + strtmp[4] + ",0,0,0";
									try
									{
											Log.d("time is",str);
											writeSDFile("/mnt/sdcard/etPowerOff.txt",str);
									}
									catch (IOException e) 
									{
											e.printStackTrace();
									}		
								}		              	
            }
           
						if (intent.getAction().equals(Intent.MCU_POWER_ON_TIME)) 
						{
							  String strpoweron=intent.getStringExtra("powerOn");
							 	Log.e(TAG, "receiver intent  MCU_POWER_ON_TIME  str= "+strpoweron);
							 		 
							  if(strpoweron.equals("0,0,0,0,0,0,0,0")==true)
							  {
							   			try
							   			{
							   					System.out.println("cancelpoweron");
							      			String cancelPowerOnStr = "2";
							       			mFileOutputStream.write(cancelPowerOnStr.getBytes());
							       			mFileOutputStream.flush();
							    		}
							    		catch (Exception e)
							    		{
							 	   			e.printStackTrace();
							 	   		}
							  }
							  else
							  {
							  			String[] strtmp=strpoweron.split(",");		
							 				try
							 				{ 
													String str_year;
													String str_month;
													String str_date;
							            String str_hour;
													String str_min;
													if(strtmp[3].length()==1){
									 					 str_hour="0"+strtmp[3];
									 				}else{
									 					 str_hour=strtmp[3];
									 				}
													if(strtmp[4].length()==1){
									 					 str_min="0"+strtmp[4];
									 				}else{
									 					 str_min=strtmp[4];
									 				}
													if(strtmp[5].length()==1){
									 					 str_year="0"+strtmp[5];
									 				}else{
									 					 str_year=strtmp[5];
									 				}
													if(strtmp[6].length()==1){
									 					 str_month="0"+strtmp[6];
									 				}else{
									 					 str_month=strtmp[6];
									 				}
													if(strtmp[7].length()==1){
									 					 str_date="0"+strtmp[7];
									 				}else{
									 					 str_date=strtmp[7];
									 				}
													Log.d("PoweronDate------->","Year, "+ str_year+"Month "+ str_month+"Date " +str_date);
													String mcusenddate ="8"+str_year+str_month+str_date;
													Log.d(TAG, "set MCU_POWER_ON_DATE  str= "+mcusenddate);
									    		mFileOutputStream.write(mcusenddate.getBytes());
									    		mFileOutputStream.flush();
													   
													Thread.sleep(1000);
													if((0<=Integer.parseInt(str_hour))&&(Integer.parseInt(str_hour)<=24)&&(0<=Integer.parseInt(str_min))&&(Integer.parseInt(str_min)<=60))
													{										
												      String mcusend = "1" + str_hour+ str_min+ "00";
															Log.d(TAG, "set MCU_POWER_ON_TIME  str= "+mcusend);
												      mFileOutputStream.write(mcusend.getBytes());
												      mFileOutputStream.flush();
															String str= "Power_on_time: 20" + str_year + "," + str_month + "," + str_date + "," + str_hour +":" + str_min;
										    			try
										    			{
										    					Log.d("time is",str);
																	writeSDFile("/mnt/sdcard/Power_on.txt",str);
															}
															catch (IOException e) 
															{
																	e.printStackTrace();
										    			}
													}
													else
													{
														 Log.e(TAG, " MCU_POWER_ON_TIME is Invalid str_min="+str_min+" str_hour="+str_hour);
													}
											}
											catch (Exception e)
											{
											 	 e.printStackTrace();
											}
											SetMcuTime();
								}
        		}
						if (intent.getAction().equals(Intent.MCU_POWER_OFF_TIME)) 
						{     
						     	String strpoweroff=intent.getStringExtra("powerOff");					
						   		Log.d(TAG, "receiver intent  MCU_POWER_OFF_TIME str ="+strpoweroff);
						      String[] strtmp=strpoweroff.split(",");			
									try
									{
											String str_year;
											String str_month;
											String str_date;
					            String str_hour;
											String str_min;
											if(strtmp[3].length()==1){
							 					 str_hour="0"+strtmp[3];
							 				}else{
							 					 str_hour=strtmp[3];
							 				}
											if(strtmp[4].length()==1){
							 					 str_min="0"+strtmp[4];
							 				}else{
							 					 str_min=strtmp[4];
							 				}
											if(strtmp[5].length()==1){
							 					 str_year="0"+strtmp[5];
							 				}else{
							 					 str_year=strtmp[5];
							 				}
											if(strtmp[6].length()==1){
							 					 str_month="0"+strtmp[6];
							 				}else{
							 					 str_month=strtmp[6];
							 				}
											if(strtmp[7].length()==1){
							 					 str_date="0"+strtmp[7];
							 				}else{
							 					 str_date=strtmp[7];
							 				}
							       	String str= "Power_off_time: 20" + str_year + "," + str_month + "," + str_date + "," + str_hour +":" + str_min;
							    		try
							    		{
							    					Log.d("time is " ,str);
														writeSDFile("/mnt/sdcard/Power_off.txt",str);
											}
											catch (IOException e) 
											{
													e.printStackTrace();
						    			}
						      }
						 			catch (Exception e)
									{
						 				e.printStackTrace();
						 			}
						 			
						    	if(poweroff_flag)
						    	{
							    		Log.d(TAG, "  again set power off  delay ="+m_delayTime);
							   			mPowerofHandler.removeCallbacks(DelayRunable);		      
						   		}
						   		if(strpoweroff.equals("cancel")==true)
									{
											Log.d(TAG, "power  power cancel ");
											poweroff_flag=false; 
									} 
									else
									{
											m_delayTime=GetPowerOffTime(strtmp[3],strtmp[4]);
										  Log.d(TAG, "  MCU_POWER_OFF delay ="+m_delayTime);
								      mPowerofHandler.postDelayed(DelayRunable,m_delayTime);	
								      poweroff_flag=true; 
											WritePowerOffTimeToConfig(mContext,strtmp[3],strtmp[4],true);
									}		        
						}
	       			if (intent.getAction().equals(Intent.MCU_WATCHDOG_ENABLE)) 
	       			{
									  try
									  {
											  	if(mcuwatchdogFlag==false)
											  	{
										           String dogenablesend = "41" ;
										           mFileOutputStream.write(dogenablesend.getBytes());
										           mFileOutputStream.flush();
										           Thread.sleep(10);
											     		 mcuwatchdogFlag=true;
											  	}
									       	String feeddogsend = "5" ;
									       	mFileOutputStream.write(feeddogsend.getBytes());
									       	mFileOutputStream.flush();   
									 	}
									 	catch (Exception e)
										{
									 	 e.printStackTrace();
									 	}
  
              }
							if (intent.getAction().equals(Intent.MCU_WATCHDOG_DISABLE)) 
							{
					          Log.d(TAG, "receiver intent MCU_WATCHDOG_DISABLE");
							      try
							      {
									       String feeddogsend = "40" ;
									       mFileOutputStream.write(feeddogsend.getBytes());
									       mFileOutputStream.flush();
										 		 mcuwatchdogFlag=false;
							    	}
							 	    catch (Exception e)
								  	{
							 	   		e.printStackTrace();
							 	   	}  
              }
				      if (intent.getAction().equals(Intent.ACTION_TIME_CHANGED))
				      {
				      	  Log.d(TAG, "receiver intent ACTION_TIME_CHANGED");
					  			SetMcuTime();    	  		
				      }
		
				      if (intent.getAction().equals(Intent.MCU_REBOOT))
				      {
				      	  	Log.d(TAG, "receiver intent MCU_REBOOT");
				      	  	PowerManager pm = (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
                    pm.reboot("MCU_REBOOT");
				      }
	      			if (intent.getAction().equals(Intent.MCU_SLEEP))
	      			{
	      	  				Log.d(TAG, "receiver intent MCU_SLEEP");	
										PowerManager pm = (PowerManager)mContext.getSystemService(Context.POWER_SERVICE);
                    pm.goToSleep(SystemClock.uptimeMillis());
							}
							//silent update third apk on background
							if (intent.getAction().equals("xy.update.third.apk.start")) 
							{
										Log.e(TAG, "silentupdate.third.apk.start");

										String filepath = intent.getStringExtra("filePath");
										String pkgname = intent.getStringExtra("pkgname");

										Log.e(TAG, "filepath: " + filepath);
										Log.e(TAG, "pkgname: " + pkgname);

										File file = new File(filepath);
										if (!file.exists())
										{
												Log.e(TAG, "no installOnBackground()");
												return;
										}
										installOnBackground(file, pkgname);
							}
							if(intent.getAction().equals(Intent.ACTION_SCREEN_ON))
							{
										Log.e("222222", ""+intent.getAction());
										openBlueLed();
										closeRedLed();
							}

							if(intent.getAction().equals(Intent.ACTION_SCREEN_OFF))
							{
										Log.e("222222", ""+intent.getAction());
										closeBlueLed();
										openRedLed();
							}
							
							if(intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED))
							{
										Log.e("222222", ""+intent.getAction());
										openBlueLed();
										closeRedLed();
										//SerialPortWrite("9");//mcu version
							}

        }
        
  };
	public void writeSDFile(String fileName, String write_str) throws IOException
	{    
        File file = new File(fileName);      
        FileOutputStream fos = new FileOutputStream(file);      
        byte [] bytes = write_str.getBytes();     
        fos.write(bytes);     
        fos.close();   
	}  
  //add by jessica,silent installOnBackground
	public void installOnBackground(File file, String pkgname)
	{
			int installFlags = 0;
			Uri packageUri = Uri.fromFile(file);

			PackageManager pm = mContext.getPackageManager();
			installFlags |= PackageManager.INSTALL_REPLACE_EXISTING;

			MyPackageInstallObserver observer = new MyPackageInstallObserver();
			pm.installPackage(packageUri, observer, installFlags, pkgname);
	}
	private void startActivity1(String packName)
	{
			Intent intent = mContext.getPackageManager().getLaunchIntentForPackage(packName);
			mContext.startActivity(intent);
  }
	class MyPackageInstallObserver extends IPackageInstallObserver.Stub
	{
				@Override
				public void packageInstalled(String packageName, int returnCode)
						throws RemoteException
				{
					Log.e(TAG, "packageName = " + packageName);
					Log.e(TAG, "returnCode = " + returnCode);
					
					if (returnCode == 1)
					{
							Log.d(TAG,"install OK");
							startActivity1(packageName);
					}
					else
					{
							Log.d(TAG,"install failed");
					}
				}
	}
	// JNI
	private native static FileDescriptor SerialPort_open(String path, int baudrate, int flags);
	public native void SerialPort_close();

}
