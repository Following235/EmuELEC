package com.md.timingswitch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.http.util.EncodingUtils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;

public class MyBroadcast extends BroadcastReceiver {

	private String StrPowerOff;
	private static String StrPowerOn;
	FileInputStream fis = null;
	private static String line ;
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		if(intent.getAction().equals("android.intent.action.BOOT_COMPLETED")){
			Log.e("eric", "boot2");
			//Intent intent2 = new Intent(context,MainActivity.class);
			//intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			//context.startActivity(intent2);
			SetPowerOnTime(context);
			SetPowerOffTime(context);
			
		}
	}
	public void SetPowerOnTime(Context context) {
		//String everyTime = "1,0,0," + "0" + "," + "0" + ",0,0,0";
		String rootPath = Environment.getExternalStorageDirectory().getPath();
		try {
			StrPowerOn=readSDFile(rootPath+"/etPowerOn.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.e("eric111", StrPowerOn);
		Intent intent = new Intent("com.example.md.boot_everytime");
		intent.putExtra("etPowerOn", StrPowerOn);
		context.sendBroadcast(intent);
	}

	public void SetPowerOffTime(Context context) {
		//String everyTime = "1,0,0," + "0" + "," + "0" + ",0,0,0";
		String rootPath = Environment.getExternalStorageDirectory().getPath();
		try {
			StrPowerOff=readSDFile(rootPath+"/etPowerOff.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Intent intent = new Intent("com.example.md.ShutDown_everytime");
		intent.putExtra("etPower", StrPowerOff);
		Log.e("eric", "powerOff");
		context.sendBroadcast(intent);
	}
	public String readSDFile(String filePath) throws IOException{
		
		FileReader fr = new FileReader(filePath);
		//缓冲读，可以一行一行的读取内容 
		BufferedReader br = new BufferedReader(fr);
		
		line = br.readLine();
		if(line == null){
			Log.e("eric_null", line);
		}
		Log.e("eric_line", line);
		
		/*File file = new File(filePath);
		Log.e("eric", "" +file.listFiles());
		try {
			fis = new FileInputStream(file);
			byte[] buff = new byte[fis.available()];
			fis.read();
			FileName = EncodingUtils.getString(buff, "UTF-8");
			Log.e(FileName, FileName);
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	*/			
		return line;		
	}

}
