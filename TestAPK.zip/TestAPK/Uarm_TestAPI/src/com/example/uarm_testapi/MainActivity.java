package com.example.uarm_testapi;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener, Runnable {

	public static final String MCU_SHUT_DOWN = "android.intent.action.shutdown";
	public static final String MCU_POWER_ON_TIME = "com.example.jt.boottime";
	public static final String MCU_POWER_OFF_TIME = "com.example.jt.shutdowntime";
	public static final String MCU_WATCHDOG_ENABLE = "android.intent.action.pubds_watchdogenable";
	public static final String MCU_WATCHDOG_DISABLE = "android.intent.action.pubds_watchdogdisable";
	public static final String MCU_REBOOT = "android.intent.action.pubds_reboot";
	public static final String MCU_SLEEP = "android.intent.action.pubds_sleep";

	// power on/off time
	private Button btn_power_on;
	private Button btn_power_off;
	private Button btn_power_cancle_on;
	private Button btn_power_cancle_off;
	private EditText text_power_on;
	private EditText text_power_off;

	// system on/off
	private Button btn_sys_reboot;
	private Button btn_sys_shutdown;
	private Button btn_sys_sleep;

	// watch dog
	private Button btn_start_watchdog;
	private Button btn_stop_watchdog;
	private EditText text_watchdog_value;
	private Thread feedThread;
	private int feed_dog_time;

	// GPIO0 demo
	private Button btn_gpio_high;
	private Button btn_gpio_low;
	// private Button btn_gpio_read;
	private TextView text_gpio_value0;
	private TextView text_gpio_value1;
	private TextView text_gpio_value2;
	private TextView text_gpio_value3;
	// private int mLength = 12;

	// TimePicker and Datapicker
	private TimePicker timePicker;
	private DatePicker datePicker;
	private Calendar calendar;
	private int CurYear;
	private int CurMonth;
	private int CurDays;
	private int CurHours;
	private int CurMin;
	private int CurSecond;
	private static String strMonth;
	private static String strDays;
	private static String strHours;
	private long CurTime;
	private long SetPowerOn;
	private long SetPowerOff;
	private Spinner spinner;
	private Switch tSwitch;
	private int flagTime = 0;
	private ListView timeList;
	private TextView empty;
	private int id = 0;
	protected List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
	protected SharedPreferences shared;
	protected Editor editor;
	private String bootHit;
	private String year;
	private String month;
	private String days;
	private String hours;
	private String min;
	private String everybootHit;
	private String ShutDownTime;
	private String eShutDownTime;
	/*
	 * private static File gpio_0 = new
	 * File("/sys/class/backlight/rk28_bl/gpio0"); private static File gpio_1 =
	 * new File("/sys/class/backlight/rk28_bl/gpio1"); private static File
	 * gpio_2= new File("/sys/class/backlight/rk28_bl/gpio2"); private static
	 * File gpio_3 = new File("/sys/class/backlight/rk28_bl/gpio3");
	 */
	public final static String GPIO0_HIGH = "0001";
	public final static String GPIO0_LOW = "0000";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		bootHit = getResources().getString(R.string.bootHit);
		everybootHit = getResources().getString(R.string.everybootHit);
		ShutDownTime = getResources().getString(R.string.ShutdownHit);
		eShutDownTime = getResources().getString(R.string.everyShutDownHit);
		year = getResources().getString(R.string.YearHit);
		month = getResources().getString(R.string.MonthHit);
		days = getResources().getString(R.string.DaysHit);
		hours = getResources().getString(R.string.HoursHit);
		min = getResources().getString(R.string.MinHit);
		

		// power on/off time
		btn_power_on = (Button) findViewById(R.id.poweronTime);
		btn_power_off = (Button) findViewById(R.id.poweroffTime);
		btn_power_cancle_on = (Button) findViewById(R.id.canclePoweron);
		btn_power_cancle_off = (Button) findViewById(R.id.canclePoweroff);
		text_power_on = (EditText) findViewById(R.id.textPoweron);
		text_power_off = (EditText) findViewById(R.id.textPoweroff);
		btn_power_on.setOnClickListener(this);
		btn_power_off.setOnClickListener(this);
		btn_power_cancle_on.setOnClickListener(this);
		btn_power_cancle_off.setOnClickListener(this);

		// system on/off
		btn_sys_reboot = (Button) findViewById(R.id.system_reboot);
		btn_sys_shutdown = (Button) findViewById(R.id.SystemShutdown);
		btn_sys_sleep = (Button) findViewById(R.id.system_sleep);
		btn_sys_reboot.setOnClickListener(this);
		btn_sys_shutdown.setOnClickListener(this);
		btn_sys_sleep.setOnClickListener(this);

		// watch dog
		btn_start_watchdog = (Button) findViewById(R.id.start_watchdog);
		btn_stop_watchdog = (Button) findViewById(R.id.stop_watchdog);
		text_watchdog_value = (EditText) findViewById(R.id.watch_dog_time);
		btn_start_watchdog.setOnClickListener(this);
		btn_stop_watchdog.setOnClickListener(this);

		// GPIO0 demo
		btn_gpio_high = (Button) findViewById(R.id.gpio_sethigh0);
		btn_gpio_low = (Button) findViewById(R.id.gpio_setlow0);
		// btn_gpio_read = (Button) findViewById(R.id.gpio_read);
		text_gpio_value0 = (TextView) findViewById(R.id.gpioValue0);
		text_gpio_value1 = (TextView) findViewById(R.id.gpioValue1);
		text_gpio_value2 = (TextView) findViewById(R.id.gpioValue2);
		text_gpio_value3 = (TextView) findViewById(R.id.gpioValue3);
		btn_gpio_high.setOnClickListener(this);
		btn_gpio_low.setOnClickListener(this);
		// btn_gpio_read.setOnClickListener(this);

		// 时间设置成功记录
		timeList = (ListView) findViewById(R.id.listView1);

		// 设置listview为空的时候的提示
		timeList.setEmptyView(findViewById(R.id.text_hit));

		// 保存当前设置状态
		shared = this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
		editor = shared.edit();
		btn_power_on.setEnabled(shared.getBoolean("btn_power_on", false));
		btn_power_cancle_on.setEnabled(shared.getBoolean("btn_power_cancle_on", false));
		btn_power_off.setEnabled(shared.getBoolean("btn_power_off", false));
		btn_power_cancle_off.setEnabled(shared.getBoolean("btn_power_cancle_off", false));

		// 定时开关的监听
		tSwitch = (Switch) findViewById(R.id.switch1);
		tSwitch.setChecked(shared.getBoolean("tSwitch", false));
		tSwitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if (isChecked) {
					btn_power_off.setEnabled(true);
					btn_power_on.setEnabled(true);
					editor.putBoolean("btn_power_on", btn_power_on.isEnabled());
					editor.putBoolean("btn_power_off", btn_power_off.isEnabled());
					editor.putBoolean("tSwitch", isChecked);
					editor.commit();
				} else {
					EveryTimePowerOff();
					EveryTimePowerOn();
					CanclePowerOn();
					CanclePowerOff();
					btn_power_off.setEnabled(false);
					btn_power_on.setEnabled(false);
					btn_power_cancle_on.setEnabled(false);
					btn_power_cancle_off.setEnabled(false);
					editor.putBoolean("btn_power_on", btn_power_on.isEnabled());
					editor.putBoolean("btn_power_cancle_on", btn_power_cancle_on.isEnabled());
					editor.putBoolean("btn_power_off", btn_power_off.isEnabled());
					editor.putBoolean("btn_power_cancle_off", btn_power_cancle_off.isEnabled());
					editor.putBoolean("tSwitch", isChecked);
					editor.commit();
				}
			}
		});

		// 下拉菜单
		spinner = (Spinner) findViewById(R.id.spinner1);
		String Item[] = getResources().getStringArray(R.array.spinnername);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, Item);
		adapter.setDropDownViewResource(R.layout.spinner_layout1);
		spinner.setAdapter(adapter);
		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Log.e("" + position, "" + id);
				if (position == 0) {
					flagTime = 0;
				} else if (position == 1) {
					flagTime = 1;
				} else if (position == 2) {
					flagTime = 2;
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub

			}
		});

		// 时间的获取
		timePicker = (TimePicker) findViewById(R.id.timePicker1);
		datePicker = (DatePicker) findViewById(R.id.datePicker1);
		GetCurTime();
		SetTimePicker();
		SetDatePicker();
	}

	// 打开wifi设置
	public void OpenWifi(View v) {
		WifiManager wm = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
		wm.setWifiEnabled(true);
		Intent mIntent = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);
		startActivity(mIntent);		
	}
	
	public void OpenBT(View v){
		BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		bluetoothAdapter.enable();
		Intent mIntent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
		startActivity(mIntent);
	}

	public void addTimeList(String time) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.clear();
		id++;
		map.put("id", id + "");
		map.put("content", time);
		list.add(map);
		SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.time, new String[] { "id", "content" },
				new int[] { R.id.textView1, R.id.textView2 });
		timeList.setAdapter(adapter);
		if (id == 9) {
			list.clear();
			id = 0;
			addTimeList(time);
		}
	}

	public void GetCurTime() {
		calendar = Calendar.getInstance();
		CurYear = calendar.get(Calendar.YEAR);
		CurMonth = calendar.get(Calendar.MONTH) + 1;
		CurDays = calendar.get(Calendar.DAY_OF_MONTH);
		CurSecond = calendar.get(Calendar.SECOND);
	}

	public void SetTimePicker() {
		timePicker.setOnTimeChangedListener(new OnTimeChangedListener() {

			@Override
			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
				// TODO Auto-generated method stub
				CurHours = hourOfDay;
				CurMin = minute;
				Log.e("" + CurHours, "" + CurMin);
			}
		});
	}

	public void SetDatePicker() {
		datePicker.init(CurYear, CurMonth - 1, CurDays, new OnDateChangedListener() {

			@Override
			public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
				// TODO Auto-generated method stub
				CurYear = year;
				CurMonth = monthOfYear + 1;
				CurDays = dayOfMonth;
				Log.e(" " + CurYear, "" + CurMonth + "  " + CurDays);
			}
		});
	}

	private String getGpioString(String path) {
		String defString = "0";// 默认值
		try {
			@SuppressWarnings("resource")
			BufferedReader reader = new BufferedReader(new FileReader(path));
			defString = reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return defString;
	}

	private boolean RootCommand(String command) {
		Process process = null;
		DataOutputStream os = null;
		try {
			process = Runtime.getRuntime().exec("su");
			os = new DataOutputStream(process.getOutputStream());
			os.writeBytes(command + "\n");
			os.writeBytes("exit\n");
			os.flush();
			process.waitFor();
		} catch (Exception e) {
			return false;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
				process.destroy();
			} catch (Exception e) {
			}
		}
		return true;
	}

	private void read_gpio0() {
		text_gpio_value0.setText("" + getGpioString("/sys/class/backlight/rk28_bl/gpio0"));
	}

	private void read_gpio1() {
		text_gpio_value1.setText("" + getGpioString("/sys/class/backlight/rk28_bl/gpio1"));
	}

	private void read_gpio2() {
		text_gpio_value2.setText("" + getGpioString("/sys/class/backlight/rk28_bl/gpio2"));
	}

	private void read_gpio3() {
		text_gpio_value3.setText("" + getGpioString("/sys/class/backlight/rk28_bl/gpio3"));
	}

	private boolean set_gpio0_high() {
		boolean FLAG = RootCommand("echo  1 > /sys/class/backlight/rk28_bl/gpio0");
		read_gpio0();
		return FLAG;
	}

	public boolean set_gpio1_high(View v) {
		boolean FLAG = RootCommand("echo  1 > /sys/class/backlight/rk28_bl/gpio1");
		read_gpio1();
		return FLAG;
	}

	public boolean set_gpio2_high(View v) {
		boolean FLAG = RootCommand("echo  1 > /sys/class/backlight/rk28_bl/gpio2");
		read_gpio2();
		return FLAG;
	}

	public boolean set_gpio3_high(View v) {
		boolean FLAG = RootCommand("echo  1 > /sys/class/backlight/rk28_bl/gpio3");
		read_gpio3();
		return FLAG;
	}

	public boolean set_gpio0_low() {
		boolean FLAG = RootCommand("echo  0 > /sys/class/backlight/rk28_bl/gpio0");
		read_gpio0();
		return FLAG;
	}

	public boolean set_gpio1_low(View v) {
		boolean FLAG = RootCommand("echo  0 > /sys/class/backlight/rk28_bl/gpio1");
		read_gpio1();
		return FLAG;
	}

	public boolean set_gpio2_low(View v) {
		boolean FLAG = RootCommand("echo  0 > /sys/class/backlight/rk28_bl/gpio2");
		read_gpio2();
		return FLAG;
	}

	public boolean set_gpio3_low(View v) {
		boolean FLAG = RootCommand("echo  0 > /sys/class/backlight/rk28_bl/gpio3");
		read_gpio3();
		return FLAG;
	}

	public boolean gpio_input0(View v) {
		return RootCommand("echo  2 > /sys/class/backlight/rk28_bl/gpio0");
	}

	public boolean gpio_input1(View v) {
		return RootCommand("echo  2 > /sys/class/backlight/rk28_bl/gpio1");
	}

	public boolean gpio_input2(View v) {
		return RootCommand("echo  2 > /sys/class/backlight/rk28_bl/gpio2");
	}

	public boolean gpio_input3(View v) {
		return RootCommand("echo  2 > /sys/class/backlight/rk28_bl/gpio3");
	}

	private void reboot() {
		Intent intent = new Intent(MCU_REBOOT);
		sendBroadcast(intent);
	}

	private void shutdown() {
		Intent intent = new Intent(MCU_SHUT_DOWN);
		sendBroadcast(intent);
	}

	private void sleep() {
		Intent intent = new Intent(MCU_SLEEP);
		sendBroadcast(intent);
	}

	private void startFeedDog() {
		String tmpContent = text_watchdog_value.getText().toString();
		// btn_start_watchdog.setText(R.string.ready_watchdog);
		if (tmpContent == null || tmpContent.trim().length() == 0) {
			text_watchdog_value.setError(getResources().getString(R.string.setTimeHit));
			// Toast.makeText(this, "Feed Watch Dog No Time",
			// Toast.LENGTH_SHORT).show();
			// enableWatchDog();
			return;
		}
		Log.e("eric", "startFeedDog");
		text_watchdog_value.setEnabled(false);
		btn_start_watchdog.setEnabled(false);
		Toast.makeText(this, "Feed Watch Dog Time : " + tmpContent + "MS", Toast.LENGTH_SHORT).show();
		feed_dog_time = Integer.parseInt(tmpContent);
		if (feedThread == null)
			feedThread = new Thread(this);

		feedThread.start();
	}

	private void enableWatchDog() {
		Intent intent = new Intent(MCU_WATCHDOG_ENABLE);
		sendBroadcast(intent);
	}

	private void disableWatchDog() {
		Toast.makeText(this, "Stop Feed Watch Dog", Toast.LENGTH_SHORT).show();
		if (feedThread != null) {
			feedThread.interrupt();
			feedThread = null;
		}
		text_watchdog_value.setEnabled(true);
		btn_start_watchdog.setEnabled(true);
		btn_start_watchdog.setText(R.string.start_watchdog);

		Intent intent = new Intent(MCU_WATCHDOG_DISABLE);
		sendBroadcast(intent);
	}

	@SuppressLint("ShowToast")
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.system_reboot:
			reboot();
			break;
		case R.id.SystemShutdown:
			shutdown();
			break;
		case R.id.system_sleep:
			sleep();
			break;
		case R.id.gpio_sethigh0:
			if (set_gpio0_high()) {
				Toast.makeText(this, "Set GPIO0 High Success!", 500).show();
			} else {
				Toast.makeText(this, "Set GPIO0 High Failed!", 500).show();
			}
			break;
		case R.id.gpio_setlow0:
			if (set_gpio0_low()) {
				Toast.makeText(this, "Set GPIO0 Low Success!", 500).show();
			} else {
				Toast.makeText(this, "Set GPIO0 Low Failed!", 500).show();
			}
			break;
		case R.id.gpio_read:
			// read_gpio0();
			break;
		case R.id.start_watchdog:
			startFeedDog();
			break;
		case R.id.stop_watchdog:
			disableWatchDog();
			break;
		case R.id.poweroffTime:
			PowerOffTime();
			break;
		case R.id.canclePoweroff:
			EveryTimePowerOff();
			CanclePowerOff();
			break;
		case R.id.poweronTime:
			PowerOnTime();
			break;
		case R.id.canclePoweron:
			EveryTimePowerOn();
			CanclePowerOn();
			break;
		}

	}

	public void CanclePowerOn() {
		Intent bootintent = new Intent("com.example.jt.boottime");
		bootintent.putExtra("powerOn", "0,0,0,0,0,0,0,0");
		this.sendBroadcast(bootintent);
		btn_power_on.setEnabled(true);
		btn_power_cancle_on.setEnabled(false);
		editor.putBoolean("btn_power_on", btn_power_on.isEnabled());
		editor.putBoolean("btn_power_cancle_on", btn_power_cancle_on.isEnabled());
		editor.commit();
		// Toast.makeText(MainActivity.this, "取消定时开机",
		// Toast.LENGTH_SHORT).show();
	}

	public void EveryTimePowerOn() {
		Intent intent = new Intent("com.example.md.boot_everytime");// 每天开机
		intent.putExtra("etPowerOn", "0,0,0,0,0,0,0,0");
		this.sendBroadcast(intent);
		addTimeList(getResources().getString(R.string.CancelHit));
	}

	public void FormatTimetoString() {
		if (("" + CurMonth).length() == 1) {
			strMonth = "0" + CurMonth;
		} else {
			strMonth = "" + CurMonth;
		}
		if (("" + CurDays).length() == 1) {
			strDays = "0" + CurDays;
		} else {
			strDays = "" + CurDays;
		}
		if (("" + CurHours).length() == 1) {
			strHours = "0" + CurHours;
		} else {
			strHours = "" + CurHours;
		}
	}

	public void PowerOnTime() {

		// 获取当前时间
		
		CurTime = calendar.getTimeInMillis();
		Log.e("PowerOnTime", "" + CurTime);
		// 将设定的时间转化为毫秒
		FormatTimetoString();
		String bootTime = "" + CurYear + strMonth + strDays + strHours + CurMin + CurSecond;
		Log.e("eric2", "" + strMonth);
		Log.e("eric1" + bootTime, bootTime);
		try {
			calendar.setTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(bootTime));
			SetPowerOn = calendar.getTimeInMillis();
			Log.e("eric" + bootTime, "" + SetPowerOn);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (CurTime <= SetPowerOn) {
			if (flagTime == 0) {
				String Ontime = "1,0,0," + CurHours + "," + CurMin + "," + (CurYear - 2000) + "," + CurMonth + ","
						+ CurDays;
				String showTimeOn = bootHit + CurYear + year + CurMonth + month + CurDays + days + CurHours + hours + CurMin
						+ min;
				Intent bootintent = new Intent("com.example.jt.boottime");
				bootintent.putExtra("powerOn", Ontime);
				this.sendBroadcast(bootintent);
				btn_power_on.setEnabled(false);// 设置成功之后取消点击
				btn_power_cancle_on.setEnabled(true);
				addTimeList(showTimeOn);
				editor.putBoolean("btn_power_on", btn_power_on.isEnabled());
				editor.putBoolean("btn_power_cancle_on", btn_power_cancle_on.isEnabled());
				editor.commit();
				// Toast.makeText(MainActivity.this, "设置成功",
				// Toast.LENGTH_SHORT).show();
			} else if (flagTime == 1) {
				String everyTime = "1,0,0," + CurHours + "," + CurMin + ",0,0,0";
				Intent intent = new Intent("com.example.md.boot_everytime");// 每天开机
				String etShowTimeOn = everybootHit + CurYear + year + CurMonth + month + CurDays + days + CurHours + hours
						+ CurMin + min;
				intent.putExtra("etPowerOn", everyTime);
				this.sendBroadcast(intent);
				btn_power_on.setEnabled(false);// 设置成功之后取消点击
				btn_power_cancle_on.setEnabled(true);
				addTimeList(etShowTimeOn);
				// Toast.makeText(MainActivity.this, "设置成功",
				// Toast.LENGTH_SHORT).show();
			}
		} else {
			Toast.makeText(MainActivity.this, getResources().getString(R.string.ToastHit), Toast.LENGTH_SHORT).show();
		}
	}

	public void CanclePowerOff() {
		Intent offintent = new Intent("com.example.jt.shutdowntime");
		offintent.putExtra("powerOff", "cancel");
		this.sendBroadcast(offintent);
		btn_power_off.setEnabled(true);
		btn_power_cancle_off.setEnabled(false);
		editor.putBoolean("btn_power_off", btn_power_off.isEnabled());
		editor.putBoolean("btn_power_cancle_off", btn_power_cancle_off.isEnabled());
		editor.commit();
		// Toast.makeText(MainActivity.this, "取消定时关机",
		// Toast.LENGTH_SHORT).show();
	}

	public void EveryTimePowerOff() {
		Intent offintent = new Intent("com.example.md.ShutDown_everytime");
		offintent.putExtra("etPower", "cancel");
		this.sendBroadcast(offintent);
		addTimeList(getResources().getString(R.string.CancelHit));
	}

	public void PowerOffTime() {

		// 获取当前时间
		Calendar calendar1 = Calendar.getInstance();
		CurTime = calendar1.getTimeInMillis();
		Log.e("PowerOffTime", "" + CurTime);
		// 将设定的时间转化为毫秒
		FormatTimetoString();
		String shutdownTime = "" + CurYear + strMonth + strDays + strHours + CurMin + CurSecond;
		Log.e("eric", shutdownTime);
		try {
			calendar.setTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(shutdownTime));
			SetPowerOff = calendar.getTimeInMillis();
			Log.e("eric" + shutdownTime, "" + SetPowerOff);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (CurTime <= SetPowerOff) {
			if (flagTime == 0) {
				String boottime = "1,0,0," + CurHours + "," + CurMin + "," + (CurYear - 2000) + "," + CurMonth + ","
						+ CurDays;
				Intent bootintent = new Intent("com.example.jt.shutdowntime");// 单次关机
				String ShowTimeOff = ShutDownTime + CurYear + year + CurMonth + month + CurDays + days + CurHours + hours + CurMin
						+ min;
				bootintent.putExtra("powerOff", boottime);
				this.sendBroadcast(bootintent);
				btn_power_off.setEnabled(false);// 设置成功之后取消点击
				btn_power_cancle_off.setEnabled(true);
				addTimeList(ShowTimeOff);
				editor.putBoolean("btn_power_off", btn_power_off.isEnabled());
				editor.putBoolean("btn_power_cancle_off", btn_power_cancle_off.isEnabled());
				editor.commit();
				// Toast.makeText(MainActivity.this, "设置成功",
				// Toast.LENGTH_SHORT).show();
			} else if (flagTime == 1) {
				String everyTime = "1,0,0," + CurHours + "," + CurMin + ",0,0,0";
				Intent intent = new Intent("com.example.md.ShutDown_everytime");// 每天关机
				String etShowTimeOff = eShutDownTime + CurYear + year + CurMonth + month + CurDays + days + CurHours + hours
						+ CurMin + min;
				intent.putExtra("etPower", everyTime);
				this.sendBroadcast(intent);
				btn_power_off.setEnabled(false);// 设置成功之后取消点击
				btn_power_cancle_off.setEnabled(true);
				addTimeList(etShowTimeOff);
				// Toast.makeText(MainActivity.this, "设置成功",
				// Toast.LENGTH_SHORT).show();
			}

		} else {
			Toast.makeText(MainActivity.this, getResources().getString(R.string.ToastHit), Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public void run() {
		try {
			while (!Thread.interrupted()) {
				enableWatchDog();
				Thread.sleep(feed_dog_time);
			}
		} catch (InterruptedException e) {
		}

	}

}
